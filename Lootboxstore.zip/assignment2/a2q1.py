cost_bronze = 2.50
cost_silver = 5.00
cost_gold = 7.50

lootbox_bronze = "Bronze"
lootbox_silver = "Silver"
lootbox_gold = "Gold"

name = input("Enter a username: ")
print("")
print("Welcome to the menu" ,name, "you have three options")

#Menu
print("1. Common " + lootbox_bronze + " (${:.2f}".format(cost_bronze)  + ")")
print("2. Rare " + lootbox_silver + " (${:.2f}".format(cost_silver)  + ")")
print("3. Epic " +  lootbox_gold +  " (${:.2f}".format(cost_gold) + ")")
print("")


def calculate_cost(lootbox_rarity,lootbox, lootbox_cost):
    print(lootbox_rarity, lootbox,"$" + "{:.2f}".format(lootbox_cost))
    print("")
    items = 0
    while True:
        items = int(input("How many " + lootbox + " ($"  + "{:.2f}".format(lootbox_cost) + ")" + " would you like? "))
        print("")
        if items > 0:
            break
        print("Enter a number greater than 0")
        print("")

    total_cost = items * lootbox_cost
    receipt(name,items,total_cost,lootbox,lootbox_cost)

def receipt(name, items, total_cost, lootbox, lootbox_cost):
    print("   Thanks",name,"here is your receipt")
    print("---------------------------------------------")
    print(str(items)+ "x", lootbox, "$" + "{:.2f}".format(lootbox_cost))
    print("---------------------------------------------")
    print("Total cost $" + "{:.2f}".format(total_cost))
    print("")
    print("Thank you! Good luck, gamer")

while True:
    option = input("Please enter a number between 1-3: ")
    print("")
    if option == "1":
        calculate_cost("Common","Bronze", cost_bronze)
        break
        
    elif option == "2":
        calculate_cost("Rare","Silver", cost_silver)
        break
    
    elif option == "3":
        calculate_cost("Epic","Gold", cost_gold)
        break

    else:
        print("Invalid number, please enter a number between 1-3")
        

  
        
