import random

cost_bronze = 2.50
cost_silver = 5.00
cost_gold = 7.50

lootbox_bronze = "Bronze"
lootbox_silver = "Silver"
lootbox_gold = "Gold"

amount_bronze = 0
amount_silver = 0
amount_gold = 0

name = input("Enter a username: ")
print("")
print("Welcome to the menu" ,name, "please select a lootbox")

#Menu
print("1. Common " + lootbox_bronze + " (${:.2f}".format(cost_bronze)  + ")")
print("2. Rare " + lootbox_silver + " (${:.2f}".format(cost_silver)  + ")")
print("3. Epic " +  lootbox_gold +  " (${:.2f}".format(cost_gold) + ")")
print("4. Complete purchase")
print("")

def final_cost(amount_bronze,amount_silver,amount_gold, cost_bronze, cost_silver,cost_gold):
    total_cost = amount_bronze * cost_bronze + amount_silver * cost_silver + amount_gold * cost_gold
    receipt(name,amount_bronze,amount_silver,amount_gold, cost_bronze, cost_silver,cost_gold, lootbox_bronze,lootbox_silver,lootbox_gold,total_cost)

#printreceipt 
def receipt(name,amount_bronze,amount_silver,amount_gold, cost_bronze, cost_silver,cost_gold, lootbox_bronze,lootbox_silver,lootbox_gold,total_cost):
    print("   Thanks",name,"here is your receipt")
    print("---------------------------------------------")
    if amount_bronze > 0:
        print(str(amount_bronze)+ "x", lootbox_bronze, "$" + "{:.2f}".format(cost_bronze))
        print("")
       
    if amount_silver > 0:    
        print(str(amount_silver)+ "x", lootbox_silver, "$" + "{:.2f}".format(cost_silver))
        print("")
      
    if amount_gold >0:
        print(str(amount_gold)+ "x", lootbox_gold, "$" + "{:.2f}".format(cost_gold))
        print("")
    print("---------------------------------------------")
    print("Total cost $" + "{:.2f}".format(total_cost))
    print("")
    print("Thank you! Good luck, gamer")
    print("")
    

def open_box(amount, lootbox):
   
    if lootbox == lootbox_bronze:
        common_prob = 80
        rare_prob = 15

    elif lootbox == lootbox_silver:
        common_prob = 50
        rare_prob = 40
    
    else:
        common_prob = 30
        rare_prob = 50

    for i in range(amount):
        print("")
        print("Open", lootbox, "box " + str(i))
        for i in range(3):
            x = random.randint(0,100)
            if x <= common_prob:
                print("It's a common item!")
            elif x> common_prob and x<= rare_prob + common_prob:
                print("It's a rare item!")
            else:
                print("Its' a epic item!")
   

    


while True:
    option = input ("Please enter a number between 1-4: ")
    print("")
    if option == "1":
        amount_bronze = amount_bronze + int(input("How many " + lootbox_bronze + " ($"  + "{:.2f}".format(cost_bronze) + ")" + " would you like? "))
            
        
    elif option == "2":
       amount_silver = amount_silver + int(input("How many " + lootbox_silver + " ($"  + "{:.2f}".format(cost_silver) + ")" + " would you like? "))
        
    elif option == "3":
        amount_gold = amount_gold + int(input("How many " + lootbox_gold + " ($"  + "{:.2f}".format(cost_gold) + ")" + " would you like? "))
    
    elif option == "4":
        final_cost(amount_bronze,amount_silver,amount_gold, cost_bronze, cost_silver,cost_gold) 
        print("Time to Open Boxes!  ")
        print("-------------------")
        open_box(amount_bronze,lootbox_bronze)
        open_box(amount_silver,lootbox_silver)
        open_box(amount_gold,lootbox_gold)

        break
    else:
        print("Invalid number, please enter a number between 1-4")

 


   





